My talk for the SciPy LATAM 2019 conference.

You can look and execute ;-) the content with [![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/damianavila/scipy_latam_2019/master?filepath=SciPyLATAM%202019%20talk.ipynb).
