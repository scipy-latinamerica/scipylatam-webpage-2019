# SciPyLA

### Codigo para acompanamento de Taller de Visualizacion de Datos Georeferenciados SciPyLA Bogota 2019
