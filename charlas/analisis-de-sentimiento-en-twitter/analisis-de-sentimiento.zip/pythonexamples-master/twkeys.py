#Credenciales del Twitter API
#Estas credenciales ya están revocadas, usarlas le generará error.
def consumer_key():
	#Add Consumer Key (API Key)
	return "bphRC8L9YwgArcTWl6QAxd8ZW"

def consumer_secret():
	#Add Consumer Secret (API Secret)
	return "EJ0w5sJ48hRHeY5JsH5rZyTe0YzJz5gI0q3HIrFWjwqv6L4PgO"

def access_key():
	#Add Access Token
	return "217885674-FQJBc09Vfd86pqcYFaetsVK3cz6gNziJfpuQfe6j"

def access_secret():
	#Add Access Token Secret
	return "gjPiyosXOGDbYSGuisUvAs50JmBduXF6L33YwXubPPjpE"
