# Python Examples

* SentimentAnalysis: Code to download twitter stream and make sentiment analysis over it. Code from [Basic data analysis on Twitter with Python](https://medium.freecodecamp.org/basic-data-analysis-on-twitter-with-python-251c2a85062e) with some additions

### Sentiment Analysis
[![Sentiment Analysis](https://img.youtube.com/vi/rDFY51cfeX0/0.jpg)](https://www.youtube.com/watch?v=rDFY51cfeX0 "Sentiment Analysis")
